package com.example.warehouseinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;


public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DatabaseName = "Login.db";

    public DatabaseHelper(Context context) {
        super(context, "Login.db", null, 1
        );
    }

    //Create two tables, one for login and one for items
    @Override
    public void onCreate(SQLiteDatabase loginDB) {
        loginDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
        loginDB.execSQL("create Table items(itemname TEXT primary key, amount TEXT)");

    }

    //If tables already exist, don't create one
    @Override
    public void onUpgrade(SQLiteDatabase loginDB, int i, int i1) {
        loginDB.execSQL("drop Table if exists users");
        loginDB.execSQL("drop Table if exists items");
    }

    //Method to add a new user
    public Boolean insertData(String username, String password) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = loginDB.insert("users",null, contentValues);
        if(result==-1) return false;
        else
            return true;
    }

    //Method to check username against database
    public Boolean checkusername(String username) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if(cursor.getCount()> 0)
            return true;
        else
            return false;
    }

    //Method to check username and password against database
    public Boolean checkusernamepassword(String username, String password) {
        SQLiteDatabase loginDB = this.getWritableDatabase();
        Cursor cursor = loginDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    //Method to add new item to the database
    public Boolean insertItem(String itemname, String amount) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemname", itemname);
        contentValues.put("amount", amount);
        long result = loginDB.insert("items",null, contentValues);
        if(result==-1) {
            return false;
        }
        else {
            return true;
        }
    }

    //Method to update an item in the database
    public Boolean updateitem(String itemname, String amount) {
        SQLiteDatabase loginDB = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("itemname", itemname);
        contentValues.put("amount", amount);
        Cursor cursor = loginDB.rawQuery("Select * from items where itemname = ?", new String[]{itemname});
        if (cursor.getCount() > 0) {
            long result = loginDB.update("items", contentValues, "itemname=?", new String[]{itemname});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //Method to delete an item from the database
    public Boolean deleteitem(String itemname) {
        SQLiteDatabase loginDB = this.getReadableDatabase();

        Cursor cursor = loginDB.rawQuery("Select * from items where itemname = ?", new String[]{itemname});
        if (cursor.getCount() > 0) {
            long result = loginDB.delete("items","itemname=?", new String[]{itemname});

            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //Method to return cursor pointing to data
    public Cursor getitemdata () {
        SQLiteDatabase loginDB = this.getReadableDatabase();

        Cursor cursor = loginDB.rawQuery("Select * from items", null);
        return cursor;
    }
}
