package com.example.warehouseinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Inventory extends AppCompatActivity {

    //Declare Variables for interactive elements
    EditText itemname, amount;
    Button insert, settings;
    ListView listView;

    //Declare new database variable
    DatabaseHelper DB;

    //Declare array list strings to hold item names and amounts
    ArrayList<String> itemNameList = new ArrayList<String>();
    ArrayList<String> itemAmountList = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        //Assign variables to specific fields
        itemname = findViewById(R.id.itemInputField);
        amount = findViewById(R.id.amountInputField);
        insert = findViewById(R.id.addButton);
        settings = findViewById(R.id.permissions);
        listView = (ListView) findViewById(R.id.itemList);

        //Create new database variable
        DB = new DatabaseHelper(this);

        //Setup listview
        MyBaseAdapter myBaseAdapter = new MyBaseAdapter(Inventory.this,itemNameList,itemAmountList);
        listView.setAdapter(myBaseAdapter);

        //Create cursor to point to item data
        Cursor res =DB.getitemdata();

        //If Database is empty, show message
        if(res.getCount()==0) {
            Toast.makeText(Inventory.this, "The Database is Empty", Toast.LENGTH_SHORT).show();
        }
        while(res.moveToNext()){
            //List all items and amounts
            itemNameList.add(res.getString(0));
            itemAmountList.add(res.getString(1));
        }

        //Check if add item has been pressed
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Get item name and amount and store to variables
                String itemTXT = itemname.getText().toString();
                String amountTXT = amount.getText().toString();

                //Add item to database
                Boolean checkinsertdata = DB.insertItem(itemTXT, amountTXT);

                //If successful is display toast message and reload page
                if(checkinsertdata==true) {
                    Toast.makeText(Inventory.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                    finish();
                    overridePendingTransition(0, 0);
                    startActivity(getIntent());
                    overridePendingTransition(0, 0);
                }
                else
                    //Else display toast error message
                    Toast.makeText(Inventory.this, "Error: New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });

        //Check to see if permissions button is pressed, if so move to settings activity
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Settings.class);
                startActivity(intent);
            }
        });


    }


}