package com.example.warehouseinventory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Declare Variables for interactive elements
    EditText username, password;
    Button login, signup;

    //Declare new Database
    DatabaseHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign variables to specific fields
        username = (EditText) findViewById(R.id.usernameField);
        password = (EditText) findViewById(R.id.passwordField);
        login = (Button) findViewById(R.id.loginButton);
        signup = (Button) findViewById(R.id.signupButton);

        //Create new database variable
        DB = new DatabaseHelper(this);

        //Check to see if signup has been pressed
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Get username and password from fields
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //Check if any fields are blank
                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Please do not leave any fields blank", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkuser = DB.checkusername(user);
                    //Does user already exist? If not create new user
                    if (checkuser == false) {
                        Boolean insert = DB.insertData(user, pass);
                        if (insert == true) {
                            Toast.makeText(MainActivity.this, "Successfully Created New Account! Please Log In.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Account Creation Failed.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "Username already Exists, please try again.", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });

        //Check to see if login has been pressed
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Get username and password from fields
                String user = username.getText().toString();
                String pass = password.getText().toString();

                //Check if any fields are blank
                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(MainActivity.this, "Please do not leave any fields blank", Toast.LENGTH_SHORT).show();
                } else {
                    //Check if username and password match, if so, move to inventory screen
                    Boolean checkuserpassword = DB.checkusernamepassword(user, pass);
                    if (checkuserpassword == true) {
                        Toast.makeText(MainActivity.this, "Log in successfull!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Inventory.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Incorrect Login Information.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}