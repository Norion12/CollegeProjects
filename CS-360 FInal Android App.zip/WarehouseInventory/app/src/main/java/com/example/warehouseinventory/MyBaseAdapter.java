package com.example.warehouseinventory;

import android.Manifest;
import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MyBaseAdapter extends BaseAdapter {

    //Declare variables
    Context context;
    ArrayList<String> listItems;
    ArrayList<String> listAmounts;
    LayoutInflater inflater;
    DatabaseHelper DB;

    //Adapter constructor
    public MyBaseAdapter(Context ctx, ArrayList<String> inputItems, ArrayList<String> inputAmounts) {
        this.context = ctx;
        this.listItems = inputItems;
        this.listAmounts = inputAmounts;
        inflater = LayoutInflater.from(ctx);

    }

    //Returns number of items in item list
    @Override
    public int getCount() {
        return listItems.size();
    }
    //Returns a specific item from list
    @Override
    public Object getItem(int i) {
        return listItems.get(i);
    }

    //Returns item id - not currently used
    @Override
    public long getItemId(int i) {
        return 0;
    }

    //Gets current line of list view, assigns variables to fields
    @Override
    public View getView(int i, View view, ViewGroup parent) {
        view = LayoutInflater.from(context).inflate(R.layout.activity_custom_item_view, parent, false);
        TextView txtView = (TextView) view.findViewById(R.id.itemNameDisplay);
        TextView txtView2 = (TextView) view.findViewById(R.id.itemAmountDisplay);
        FloatingActionButton addButton= view.findViewById(R.id.addOneButton);
        FloatingActionButton subButton= view.findViewById(R.id.subtractOneButton);
        FloatingActionButton delButton= view.findViewById(R.id.deleteItemButton);
        txtView.setText(listItems.get(i));
        txtView2.setText(listAmounts.get(i));

        //Check to see if add button is pressed, if so increment amount by one
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = txtView.getText().toString();
                String amount = txtView2.getText().toString();

                //Get amount and add one
                int amountOfItems = Integer.parseInt(amount) + 1;
                String finalAmount = String.valueOf(amountOfItems);
                DB = new DatabaseHelper(context);
                DB.updateitem(item, finalAmount);

                //Update amount on page
                txtView2.setText(finalAmount);
            }
        });

        //Check to see if add button is pressed, if so decrement amount by one
        subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = txtView.getText().toString();
                String amount = txtView2.getText().toString();
                SmsManager smsManager = SmsManager.getDefault();

                //Get amount and subtract one
                int amountOfItems = Integer.parseInt(amount) - 1;
                String finalAmount = String.valueOf(amountOfItems);
                DB = new DatabaseHelper(context);
                DB.updateitem(item, finalAmount);

                //Update amount on page
                txtView2.setText(finalAmount);

                //If permissions have been granted, send sms message if an amount reaches 0
                if (ContextCompat.checkSelfPermission(context,Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
                        && amountOfItems == 0) {
                    //Create variable to use SMS messaging
                    TelephonyManager tMgr = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);

                    //Set telephone number for this device
                    String THISDEVICEPHONENUMBER = "6505551212";

                    //Send SMS message and show toast message to notify user
                    smsManager.sendTextMessage(THISDEVICEPHONENUMBER, null, item + " inventory has reached 0. Please Restock.", null, null);
                    Toast.makeText(context, "Out of Stock SMS sent for " + item, Toast.LENGTH_SHORT).show();

                }
            }
        });

        //Check to see if the delete button has been pressed
        delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = txtView.getText().toString();
                DB = new DatabaseHelper(context);

                //Delete item from database
                DB.deleteitem(item);

                //Reload the page
                Intent myIntent = new Intent(context, Inventory.class);
                context.startActivity(myIntent);
            }
        });

        return view;
    }
}
