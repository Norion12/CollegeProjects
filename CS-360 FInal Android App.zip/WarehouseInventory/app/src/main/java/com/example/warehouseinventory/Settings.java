package com.example.warehouseinventory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Settings extends AppCompatActivity {

    //Declare permission code
    private int PERMISSION_CODE =1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //Declare Variables for interactive elements
        Button buttonRequest = findViewById(R.id.yesPerButton);
        Button cancel = findViewById(R.id.noPerButton);

        //Check to see if yes button is pressed
        buttonRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Check to see if permissions have already been granted
                if (ContextCompat.checkSelfPermission(Settings.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Settings.this, "You have already granted permission for this feature.",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), Inventory.class);
                    startActivity(intent);
                } else {
                    //If permissions have not been granted, add permissions
                    ActivityCompat.requestPermissions(Settings.this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_CODE);

                    //Create a notification letting the user know that the permissions have been granted
                    Toast.makeText(Settings.this, "Permissions Granted",Toast.LENGTH_SHORT).show();

                    //Move user to Inventory Activity
                    Intent intent = new Intent(getApplicationContext(), Inventory.class);
                    startActivity(intent);
                }
            }
        });

        //Check to see if return to inventory button is pressed
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    //Return user to Inventory Activity
                    Intent intent = new Intent(getApplicationContext(), Inventory.class);
                    startActivity(intent);
            }
        });

    }
}