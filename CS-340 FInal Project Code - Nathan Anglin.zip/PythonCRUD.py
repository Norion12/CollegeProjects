from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:47111/AAC' % (username, password))
        self.database = self.client['AAC']

# Method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Method to implement the R in CRUD.
    def read(self, search):
        if search is not None:
            output = self.database.animals.find(search, {"_id":False})
            return output
        else:
            output = self.database.animals.find(search, {"_id":False})
            return output

# Method to implement the U in CRUD.
    def update(self, search, data, value):
        if search is not None:
            newvalues = { data: value }
            self.database.animals.update_many(search,{"$set": {data: value}}, search)
            output = self.database.animals.find(newvalues)
            list_output = list(output)
            json_data = dumps(list_output)
            return True
        else:
            raise Exception("Nothing to read, no search criteria given")
            return False
        
# Method to implement the D in CRUD.
    def delete(self, search):
        if search is not None:           
            result = self.database.animals.delete_many(search)
            print("{} entries were deleted.".format(result.deleted_count))
            output = self.database.animals.find(search)
            list_output = list(output)
            json_data = dumps(list_output)
            return json_data
        else:
            raise Exception("Nothing to read, no search criteria given")
            return "False"
            