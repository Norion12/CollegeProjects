//============================================================================
// Name        : Source.cpp
// Author      : Nathan Anglin
// Class       : CS-300-H7076 DSA: Analysis and Design 22EW5
// Date        : 6 / 13 / 2022
// Description : Project 2 - Hash Table
//============================================================================

#include <iostream>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

const unsigned int DEFAULT_SIZE = 179;

struct Course {
    string courseNumber = "";
    string courseTitle = "";
    vector<string> prereq;
    int numPrereq = 0;
};

//============================================================================
// Hash Table class definition
//============================================================================

class HashTable {

private:
    //Structure to hold courses
    struct Node {
        Course course;
        unsigned int key;
        Node* next;

        //Default constructor
        Node() {
            key = UINT_MAX;
            next = nullptr;
        }

        //Initialize with a course
        Node(Course aCourse) : Node() {
            course = aCourse;
        }

        //Initialize with a course and a key
        Node(Course aCourse, unsigned int aKey) : Node(aCourse) {
            key = aKey;
        }
    };

    vector<Node> courseDatabase;

    unsigned int tableSize = DEFAULT_SIZE;                      

    unsigned int hash(int key);

public:
    HashTable();
    virtual ~HashTable();
    void AddCourse(Course course);
    void PrintAlpha(vector<string> courseNumbersList);
    void PrintCourse(string courseNumber);
    Course Search(string courseNumber);
};

//Default constructor
HashTable::HashTable() {

    courseDatabase.resize(tableSize);                                           // Initalize node structure by resizing tableSize

}



//Destructor

HashTable::~HashTable() {

    courseDatabase.erase(courseDatabase.begin());                               //Erase the nodes

}

//Calculate the hash value of a given key.
unsigned int HashTable::hash(int key) {

    return key % tableSize;                                                     //Return the remainder of deviding key by the size of the table

}

void HashTable::AddCourse(Course course) {
    
    string courseNumberOnly = course.courseNumber.substr(4, -1);                //Remove leading 4 letters from course number
    unsigned key = hash(stoi(courseNumberOnly));                                //Create a key for the given course by hashing course number


    Node* oldNode = &(courseDatabase.at(key));                                  //Retrieve the node using the key

    if (oldNode == nullptr) {                                                   //If no entry is found for the key
        Node* newNode = new Node(course, key);                                  //Make a new node with this key
        courseDatabase.insert(courseDatabase.begin() + key, (*newNode));        //Insert this node into the correct key location
        
    }
    else {                                                                      //Else if the node is not in use
        if (oldNode->key == UINT_MAX) {                                         //Assign old node key to UNIT_MAX, set to key, set old node to bid and old node next to null pointer
            oldNode->key = key;
            oldNode->course = course;
            oldNode->next = nullptr;
        }
        else {                                                                  //Else find the next unused node
            while (oldNode->next != nullptr) {                                  
                oldNode = oldNode->next;
            }
            oldNode->next = new Node(course, key);                              //Add a new node to end

         
        }
    }

}

//============================================================================
// Search for course using courseNumber
//============================================================================

Course HashTable::Search(string courseNumber) {
    Course course;


    unsigned key = hash(atoi(courseNumber.c_str()));                            //Calculate hash of given course number and set to key
    Node* node = &(courseDatabase.at(key));                                     //Create a temporary node 

    if (node == nullptr || key == UINT_MAX) {                                   //If vector is empty and the key is not used
        return course;                                                          //Return blank course
    }

    if (node != nullptr && node->key !=                                         //If this vector has 1 entry and the search matches
        UINT_MAX && node->course.courseNumber.compare(courseNumber) == 0) {
        return node->course;                                                    //Return that course 
    }

    while (node != nullptr) {                                                   //While not at the end of the node vector
        if (node->course.courseNumber.compare(courseNumber) == 0) {             //If temp node matches course number
            return node->course;                                                //Return that course
        }
        node = node->next;                                                      //Increment node
    }

    return course;                                                              //If you get to this point, no match so return empty course
}



//============================================================================
// Load Courses From File method
//============================================================================
void loadCourses(string filePath, HashTable* hashTable, vector<string>& courseNumbersList) {
    
    cout << "Loading selected file: " << filePath << endl;                      
    ifstream inputFile;                                                         //Create filestream

    inputFile.open(filePath.c_str());                                           //Check that input file opened successfully
    if (inputFile.fail()) {
        cout << "Error: Can not open input file." << endl;
        return;
    }

    Course tempCourse;                                                          //Declare temp variables
    string line;
    string tempString;
    int tempNumPrereq = 0;

    while (inputFile.good()) {                                                  //While input file has data

        getline(inputFile, line);                                               //Get a line of text

        if (line.empty() == false) {                                            //If line is not tempty
            stringstream ss(line);
            if (getline(ss, tempString, ',')) {                                 //Parse line on , or endline
                if (tempString.length() > 7) {
                    cout << "Input file not saved in correct format." << endl;  //Make sure the file isn't corrupt example:text file saved with wordpad
                    return;
                }
                tempCourse.courseNumber = tempString;                           //Load value for course number into temp course
                courseNumbersList.push_back(tempString);                        //Load value into courseNumbersList - This is used to sort later on

            }
            if (getline(ss, tempString, ',')) {                                 //Load value for course title into temp course
                tempCourse.courseTitle = tempString;
                
            }
            else {                                                              //Check to make sure each line has at least 2 entries
                cout << "File invalid, one or more lines do not have a course number and title." << endl;
                return;
            }
            
            while (getline(ss, tempString, ',')) {                              //Get all prerequsites
                tempCourse.prereq.push_back(tempString);
                tempNumPrereq++;
                tempCourse.numPrereq = tempNumPrereq;                                         
            }

        }
        
        hashTable->AddCourse(tempCourse);                                       //Add course to hash table

        tempCourse = Course();                                                  //Clear tempCourse data for next entry
        tempNumPrereq = 0;                                                      //Reset tempNumPrereq to zero for next entry
        
    }

    inputFile.close();                                                          //Close input and return
    return;
}

void HashTable::PrintCourse(string courseNumber) {
    string courseNumberOnly = courseNumber.substr(4, -1);
    unsigned key = hash(stoi(courseNumberOnly));
    Course course;

    Node* node = &(courseDatabase.at(key));                                     //Create a temporary node 

    if (node == nullptr || key == UINT_MAX) {                                   //If vector is empty and the key is not used
        return;                                                                 //Return
    }

    if (node != nullptr && node->key !=                                         //If this vector has 1 entry and the search matches
        UINT_MAX && node->course.courseNumber.compare(courseNumber) == 0) {
        cout.setf(ios::left);
        cout << "| Course Number: " 
            << courseDatabase.at(key).course.courseNumber                       //Print course number and name
            << " | Course Name: ";
        cout.width(36); 
        cout << courseDatabase.at(key).course.courseTitle << " | Prerequisites: |";
        if (courseDatabase.at(key).course.numPrereq == 0) {                         
            cout << "  None  |";
        }
        for (int i = 0; i < courseDatabase.at(key).course.numPrereq; i++) {     //Print all prereqs
            cout << courseDatabase.at(key).course.prereq.at(i) << " | ";
        }
        cout << endl;
        return;                                                                 //Return
    }

    while (node != nullptr) {                                                   //While not at the end of the node vector
        if (node->course.courseNumber.compare(courseNumber) == 0) {             //If temp node matches course number
            cout.setf(ios::left);
            cout << "| Course Number: " 
                << courseDatabase.at(key).course.courseNumber                   //Print course number and name
                << " | Course Name: ";
            cout.width(36);
            cout << courseDatabase.at(key).course.courseTitle << " | Prerequisites: |";
            if (courseDatabase.at(key).course.numPrereq == 0) {
                cout << "  None  |";                                            //If no prereqs print none
            }
            for (int i = 0; i < courseDatabase.at(key).course.numPrereq; i++) { //Print all prereqs
                cout << courseDatabase.at(key).course.prereq.at(i) << " | ";
            }
            cout << endl;
            return;                                                             //Return
        }
        node = node->next;                                                      //Increment node
    }
    cout << "Not found" << endl;
    return;                                                                     //If you get to this point, no match so return empty course
}

//============================================================================
// Print all courses alphabetically by course number
//============================================================================

void HashTable::PrintAlpha(vector<string> courseNumbersList) {

    sort(courseNumbersList.begin(), courseNumbersList.end());                   //Sort vector of course numbers alphabetically
    for (int i = 0; i < courseNumbersList.size(); i++) {                        //Iterate through entire vector or 
        PrintCourse(courseNumbersList.at(i));                                   //Print current course number from vector

    }

}


//============================================================================
// MAIN
//============================================================================

int main() {
  
    int menuSelect = 0;                                                         //Delare main variables
    HashTable* courseDatabase;
    courseDatabase = new HashTable();
    string userInput = "";
    vector<string> courseNumbersList;

    while (menuSelect != 4) {                                                   //Display menu and ask for choice
        cout << "=======================================================================================================================" << endl
            << "==========================                     ABCU Course Database Menu                     ==========================" << endl
            << "======================================================================================================================="  << endl;
        cout << "  1. Load File" << endl;
        cout << "  2. Display list of all courses" << endl;
        cout << "  3. Display course" << endl;
        cout << "  4. Exit" << endl;
        cout << "Enter choice: ";
        cin >> menuSelect;

        switch (menuSelect) {
            case 1:
                cout << "=======================================================================================================================" << endl
                    << "==========================       Please enter a file name to load courses into database.     =========================="
                    << "=======================================================================================================================" << endl
                    << "Filename: ";
                userInput = "";                                                 //Take in filename 
                cin >> userInput;

                loadCourses(userInput, courseDatabase, courseNumbersList);      //Load courses from file
                break;

            case 2:
                cout << "=======================================================================================================================" << endl
                    << "==========================        All Courses sorted by course number alphabetically.        =========================="
                    << "=======================================================================================================================" << endl;

                courseDatabase->PrintAlpha(courseNumbersList);                  //Print all courses sorted alphabetically

                break;

            case 3:
                cout << "=======================================================================================================================" << endl
                    << "==========================              Please enter a course name to search for.            =========================="
                    << "=======================================================================================================================" << endl
                    << "Course number: ";
                userInput = "";                 
                cin >> userInput;                                               //Take in course number to search for
                if (userInput.length() != 7) {
                    cout << "Incorrect course number format, try again." << endl;
                    break;
                }
                courseDatabase->PrintCourse(userInput);

                break;

        }
    }

    cout << "Thank you. Program will now exit." << endl;                        //Exit Program

    return 0;
}