#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>
#include <iomanip>

/* Nathan Anglin
   Project 3
 */

using namespace std;

/*
  Function for Calling Python Procedures
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}



int main()
{   
	// Declare Variables
	int menuInput = 0;
	int userInput = 5;
	ifstream pythonInputFile;
	string itemName;
	string itemQuantity;
	int itemNumber = 0;

	while (menuInput != 4) {

		// Print Menu to screen, interpret input
		system("Color 0A");
		cout << "======================================================" << endl;
		cout << "=                    Corner Grocer                   =" << endl;
		cout << "======================================================" << endl;
		cout << "= 1 : Display Number of Times Each Grocery Item Sold =" << endl;
		cout << "= 2 : Search Specific Grocery Item Bought Per Day    =" << endl;
		cout << "= 3 : Display Number of Grocery Items as a Histogram =" << endl;
		cout << "= 4 : Exit                                           =" << endl;
		cout << "======================================================" << endl;


		//Try loop to make sure user only inters correct values in menu and calculations
		try {
			cin >> menuInput;
			if (cin.fail()) {
				throw runtime_error("Please only whole numbers.");
			}
			cout << "======================================================" << endl;


			//Check user input and preform choosen task
			switch (menuInput) {
			case 1:
				// Clear Screen, Change color to White
				system("CLS");
				system("Color 07");
				cout << "======================================================" << endl;
				cout << "=       Number of Times Each Grocery Item Sold       =" << endl;
				cout << "======================================================" << endl;
				// Call Python Function
				CallProcedure("optionOne");

				// Output Formating
				cout << "======================================================" << endl;

				// Pause, then clear screen and return to menu
				system("pause");
				system("CLS");

				break;
			case 2:
				// Clear Screen, Change color to White
				system("CLS");
				system("Color 07");
				cout << "======================================================" << endl;
				cout << "=        Specific Grocery Item Bought Per Day        =" << endl;
				cout << "======================================================" << endl;

				// Call Python Function
				CallProcedure("optionTwo");

				// Output Formating
				cout << "======================================================" << endl;

				// Pause, then clear screen and return to menu
				system("pause");
				system("CLS");
				break;

			case 3:
				// Clear Screen, Change color to White
				system("CLS");
				system("Color 07");
				cout << "======================================================" << endl;
				cout << "=       Number of Grocery Items as a Histogram       =" << endl;
				cout << "======================================================" << endl;

				// Call Python Function
				CallProcedure("optionThree");

				// Open File created in Python
				pythonInputFile.open("frequency.dat");

				// Make sure file is opened correctly
				if (!pythonInputFile.is_open()) {
					cout << "Could not open file frequency.dat." << endl;
					return 1;
				}

				// Get Name of Grocery Item
				getline(pythonInputFile, itemName, ' ');

				do {
					// Output Item Name
					cout << setw(12) << left << itemName << " : ";

					// Get Item Quantity
					getline(pythonInputFile, itemQuantity);

					// Convert Quantity to Int
					itemNumber = stoi(itemQuantity);

					// Output a * for each item bought
					for (int i = itemNumber; i > 0; i--) {
						cout << "*";
					}
					cout << endl;

					// Get next Item Name
					getline(pythonInputFile, itemName, ' ');

				} while (!pythonInputFile.fail());  // Exit once end of file has been reached

				// Close File
				pythonInputFile.close();


				// Output Formating
				cout << "======================================================" << endl;
				
				// Pause, then clear screen and return to menu
				system("pause");
				system("CLS");
				break;

			case 4:

				// User wants to exit so break loop and end program
				break;

			default:
				break;
			}
		}
		catch (runtime_error& excpt) {
			// Clear screen, change color to red
			system("CLS");
			system("Color 04");

			// Prints the error message passed by throw statement and tells user to restart program
			cout << "=================== ! INPUT ERROR ! ==================" << endl;
			cout << excpt.what() << endl;
			cout << "Reopen program and try again." << endl;
			cout << "======================================================" << endl;
			return 0;
		}


	}


}