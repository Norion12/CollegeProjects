import re
import string

# Nathan Anglin
# Project 3

#Option 1 Code
def optionOne():

    # Open Grocery text file
    groceryText = open("GroceryInput.txt", "r")
  
    # Declare a Dictionary
    groceryDict = dict()
  
    # Loop through items in File
    for item in groceryText:
        # Remove spaces
        item = item.strip()

        if item in groceryDict:
            # Add one to counter if it is in the dictionary
            groceryDict[item] = groceryDict[item] + 1
        else:
            # Set number to one if not in the dictionary
            groceryDict[item] = 1
  
    # Print the contents of dictionary
    for key in list(groceryDict.keys()):
        print(key, ":", groceryDict[key], "Sales")

#Option 2 Code
def optionTwo():
    # Open Grocery text file
    groceryText = open("GroceryInput.txt", "r")
  
    # Declare a Dictionary
    groceryDict = dict()

    # Declare and set match to False
    userMatch = False;
  
    # Loop through items in File
    for item in groceryText:
        # Remove spaces
        item = item.strip()

        if item in groceryDict:
            # Add one to counter if it is in the dictionary
            groceryDict[item] = groceryDict[item] + 1
        else:
            # Set number to one if not in the dictionary
            groceryDict[item] = 1

    # Prompt user to input search item
    userItem = input('Type Item Name: ')

    # Iterate through dictonary to find a match, if so, display match and value
    for key in list(groceryDict.keys()):
        if userItem == key:
            print(key, ":", groceryDict[key], "Sales")

            # Set match to true if there is a match
            userMatch = True;                       
    
    # If there wasn't a match, display error
    if userMatch == False:
        print("Item not found, Please try again.")

#Option 3 Code
def optionThree():

    # Open Grocery text file
    groceryText = open("GroceryInput.txt", "r")
  
    # Declare a Dictionary
    groceryDict = dict()
  
    # Loop through items in File
    for item in groceryText:
        # Remove spaces
        item = item.strip()

        if item in groceryDict:
            # Add one to counter if it is in the dictionary
            groceryDict[item] = groceryDict[item] + 1
        else:
            # Set number to one if not in the dictionary
            groceryDict[item] = 1
    # Create new file
    Output_file = open("frequency.dat", "w")
    # Print the contents of dictionary
    for key in list(groceryDict.keys()):
        # Format Text to be name with one space then count
        line = key
        line += " "
        line += str(groceryDict[key])
        line += "\n"
        # Output this line to file
        Output_file.write(line)

    # Close the file
    Output_file.close()


    
